# Landing Page

This project was to create with Javascript a menu and be able to scroll in to section.

## Getting Started

There is an HTML and CSS file. The JS file is linked.

### Prerequisites

JS Version: ES2015/ES6


## Read CSS and HTML file

In the HTML file there is 3 sections in the main part with paragraphe


### Reading Javascript

The first function is pageLoaded to read first the page and take all information we need.
Create the menu with these information.
Generate the menu with ul and li with createElement and generateMenulink.
In this function, we create an "a" element and add a link to it.
With this link, we add an event scrollintoview in order to scroll in to the section we want to read.
And finaly, we delete and replace the active section with the setActiveSection.

## Built With

* [Udacity](https://github.com/udacity/fend/tree/refresh-2019) 

## Authors

* France Tissier de Mallerais

and [Udacity](https://github.com/udacity/fend/tree/refresh-2019) 
