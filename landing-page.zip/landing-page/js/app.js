/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

//Function when the page is Loaded.
function pageLoaded(){
   //Take all informations to create the menu.
   let menuNav = getMenuNav()
   //Create the menu with the information.
   generate_menu(menuNav)
   addScrollListeners()
}  
 

//Create a table with the information id and data-nav
function getMenuNav(){
   let sectionElems = {};
   let menuNav = []
   sectionElems = document.querySelectorAll("section")
   for (let it of sectionElems){
        let menuItem = {
           id:it.getAttribute("id"), 
           title:it.getAttribute("data-nav")
        }   
     menuNav.push(menuItem)
      }
   return menuNav
}
 

//Create ul and li with a link of each section.
function generate_menu(menuNav){
   let ul = document.getElementById("navbar__list");
   for(let item of menuNav) {
      let li = document.createElement('li');
      //create the link
      let link = generateMenuLink(item.id, item.title)
      //Create the li and ul
      li.appendChild(link)
      ul.appendChild(li)
   }
}

function addScrollListeners(){
   let sectionElems = {};
   sectionElems = document.querySelectorAll("section")
   for (let it of sectionElems){
        it.addEventListener("scroll", highlight("link_" + it.getAttribute("id"))); 
   }
}

//Create the link sectionID and create scroll in to view.
function generateMenuLink(sectionID, sectionTitle){
   var link = document.createElement("a")
      //link to css attribute  for the style
      
      link.setAttribute("class","menu__link")
      if(sectionID == "section1") {link.setAttribute("class","menu__link__current")}

      link.setAttribute("id", "link_" + sectionID)
      link.innerHTML = sectionTitle
      //When clicking the section is active and it scroll
      link.addEventListener('click', function () {
         setActiveSection(sectionID)
         document.getElementById(sectionID).scrollIntoView({
            behavior:"smooth" 
        })
      })
   return link
}


// Erase and replace the section active.
function setActiveSection(sectionId){
   let current = document.getElementsByClassName("your-active-class");
   current[0].className = current[0].className.replace("your-active-class", "");
   document.getElementById(sectionId).className += "your-active-class";
}
 
function highlight(aId){
   let nowHighlight = document.getElementsByClassName("menu__link__current");
   nowHighlight[0].className = nowHighlight[0].className.replace("menu__link__current","");
   document.getElementById(aId).className = "menu__link__current";

   //1 executer setActiveSection(sectionID)
   //2 change le hilighting (peut etre creer une fonction comme setactivsection?) reprendre autre fonction supprime et replace
}
